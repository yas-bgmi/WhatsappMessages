/**
 * 
 */
/**
 * 
 */
module WhatsappMessages {
	requires java.datatransfer;
	requires java.desktop;
}