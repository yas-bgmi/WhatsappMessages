package Whatsapp;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Scanner;

public class Messages {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
			Scanner sc = new Scanner(System.in);
			System.out.println("Please Enter Your Message: ");
			String msg = sc.nextLine();
			System.out.println("How Many Times Do You Want: ");
			int size = sc.nextInt();
			
			 StringSelection stringSelection = new StringSelection(msg);
			 Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			 clipboard.setContents(stringSelection, null);
		
			 Thread.sleep(5*1000);
		 
		Robot robot = new Robot();
	 
	 	for (int i=1;i<=size; i++) {
		robot.keyPress(KeyEvent.VK_CONTROL); // virtual Keyboard
		robot.keyPress(KeyEvent.VK_V);
		
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		Thread.sleep(1*1000);
	}
		 
	}

}
